"""Structural checks of approved instruction deltas; NOT live assistant tests."""
import difflib
import hashlib
import json
import re
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'improvement_work'
BEFORE = ROOT / 'adoption_before'
FLOW = (WORK / 'guide/workflow.md').read_text()
OLD = (BEFORE / 'guide/workflow.md').read_text()
SECTIONS = ['استحقاق واختيار الإجراءات — D1', 'كفاية واختيار الوسائل — D2',
            'إطار ADHD-Friendly الشامل — D3']

class InstructionContract(unittest.TestCase):
    def test_only_new_sections_in_workflow(self):
        start = FLOW.index('## ' + SECTIONS[0])
        end = FLOW.index('## قابلية التنفيذ', start)
        self.assertEqual(FLOW[:start] + FLOW[end:], OLD)

    def test_agents_index_only(self):
        before = (BEFORE / 'AGENTS.md').read_text()
        after = (WORK / 'AGENTS.md').read_text()
        for s in SECTIONS:
            entry = f'- طبّق قسم «{s}» في `guide/workflow.md`.\n'
            self.assertEqual(after.count(entry), 1)
            after = after.replace(entry, '')
        self.assertEqual(after, before)

    def test_decision_append_only(self):
        before = (BEFORE / 'context/decisions.md').read_bytes()
        after = (WORK / 'context/decisions.md').read_bytes()
        self.assertTrue(after.startswith(before))
        self.assertEqual(after.decode().count('## DEC-022\n'), 1)

    def test_protected_files_unchanged(self):
        with zipfile.ZipFile(ROOT / 'student_guidance_improvement_2026-10-09.zip') as z:
            m = json.loads(z.read('CHANGE_MANIFEST.json'))
            for x in m['protected_files']:
                self.assertEqual(hashlib.sha256((WORK/x['path']).read_bytes()).hexdigest(), x['sha256'])
            for p in ['standards/WEEKLY_PLAN_GATE.md','catalog/weekly_operating_rules.json',
                      'tools/verify_library.py']:
                self.assertEqual((WORK/p).read_bytes(),z.read('after/'+p))
        self.assertEqual((WORK/'tools/privacy_guard.py').read_bytes(),
                         (ROOT/'improvement_baseline/tools/privacy_guard.py').read_bytes())
        self.assertEqual(json.loads((WORK/'catalog/weekly_operating_rules.json').read_text())['weekly_selection']['planned_priority_limit'], 1)

    def test_sections_unique_and_resolve(self):
        agents = (WORK/'AGENTS.md').read_text()
        for s in SECTIONS:
            self.assertEqual(FLOW.count('## '+s+'\n'),1)
            self.assertIn(s, agents)
        headings = re.findall(r'^#{2,3} (.+)$', FLOW, re.M)
        self.assertEqual(len(headings),len(set(headings)))

    def test_d1_contract(self):
        s = FLOW.split('## '+SECTIONS[0],1)[1].split('## '+SECTIONS[1],1)[0]
        for x in ['إلزام رسمي','تكليف موثق','اختياري جائز','الفئة','مسؤوله',
                  'طوال العام','خطوة الغد','غياب الشاهد لا يثبت','حالة نور مستقلة',
                  'ليست إضافة حقول','علّق الحكم المعتمد عليه فقط']:
            self.assertIn(x,s)

    def test_d2_contract(self):
        s = FLOW.split('## '+SECTIONS[1],1)[1].split('## '+SECTIONS[2],1)[0]
        for x in ['بدائل جائزة وصحيحة وكافية','تكلفة','شاهد صالح','العدد الوارد لبرنامج',
                  'عدم العثور','القياس','سرية','أصل موقع','بأثر رجعي','نسبة نجاح']:
            self.assertIn(x,s)

    def test_d3_contract(self):
        s = FLOW.split('## '+SECTIONS[2],1)[1].split('## قابلية التنفيذ',1)[0]
        for x in ['لا تشخيصًا','الشروط والمواعيد','التفاصيل تدريجيًا','ما تم وما بقي',
                  'لا يحجب الناتج الكامل','غير معتمد','بلا ساعات','اليوم المتعثر',
                  'الحماية العاجلة','لا يسقط','الاستشارات','البرامج','الحالات',
                  'التقارير','التواصل','التخطيط','التوثيق','المتابعة']:
            self.assertIn(x,s)

if __name__ == '__main__':
    unittest.main()
