"""Read-only acceptance of the authorized knowledge delta; not live assistant QA."""
import collections, hashlib, json, re
from pathlib import Path
import openpyxl

ROOT = Path(__file__).resolve().parent
BEFORE, AFTER = ROOT / 'knowledge_before', ROOT / 'improvement_work'
checks = []
def check(name, ok, detail=''):
    checks.append({'name': name, 'passed': bool(ok), 'detail': detail})
    print(('PASS ' if ok else 'FAIL ') + name + (': ' + detail if detail else ''))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def rows(path):
    return [line.strip().strip('|').split('|') for line in path.read_text().splitlines()
            if re.match(r'^\| (?:Q\d+\.\d+|S\d+) \|', line)]
rel = Path('work/planning/term1/مصفوفة_تنفيذ_الفصل_الأول.xlsx')
a, b = openpyxl.load_workbook(BEFORE / rel), openpyxl.load_workbook(AFTER / rel)
diffs = [(s.title, c.coordinate) for s in a for row in s for c in row
         if c.value != b[s.title][c.coordinate].value]
check('Four authorized workbook cell changes only', set(diffs) == {
    ('مصفوفة الفصل الأول', x) for x in ['E87','K87','L87','T87']}, str(diffs))
check('Workbook formulas unchanged', all(c.value == b[s.title][c.coordinate].value
    for s in a for row in s for c in row if c.data_type == 'f'))
check('Workbook styles unchanged', all(c._style == b[s.title][c.coordinate]._style
    for s in a for row in s for c in row))
check('Workbook native structure preserved', a.sheetnames == b.sheetnames and all(
    s.max_row == b[s.title].max_row and s.max_column == b[s.title].max_column
    and str(s.freeze_panes) == str(b[s.title].freeze_panes)
    and str(s.merged_cells) == str(b[s.title].merged_cells)
    and s.data_validations == b[s.title].data_validations
    and s.auto_filter == b[s.title].auto_filter
    and s.sheet_view.rightToLeft == b[s.title].sheet_view.rightToLeft
    and s.protection == b[s.title].protection
    for s in a))
check('No cached workbook formula errors', not [(s.title,c.coordinate,c.value)
    for s in openpyxl.load_workbook(AFTER/rel, data_only=True) for row in s for c in row
    if c.data_type == 'e'])
timing = Path('work/planning/term1/term1_eligibility_timing_decision_layer_1448.md')
mapping = Path('work/planning/term1/noor_action_mapping_review_2026-09-30.md')
tr, nr = rows(AFTER/timing), rows(AFTER/mapping)
ids = [r[0].strip() for r in tr]
check('185 unique actions preserved across timing, Noor, workbook', len(ids)==185
    and len(set(ids))==185 and ids == [r[0].strip() for r in nr]
    and ids == [str(row[0].value) for row in b['مصفوفة الفصل الأول'].iter_rows(min_row=6,max_row=190)])
check('All Noor mappings unchanged', rows(BEFORE/mapping)==nr)
counts = collections.Counter(r[3].strip() for r in tr)
check('Timing summary matches all 185 rows', counts == {
    'مستحق في أسبوع أو فترة محددة':62, 'مستمر طوال العام حسب الحاجة':40,
    'دوري أسبوعي':2,'دوري شهري':3,'دوري فصلي':13,'مشروط بوقوع حالة':54,
    'غير منطبق على المدرسة':10,'يحتاج تحققًا محددًا من المصدر':1}, str(dict(counts)))
t = (AFTER/timing).read_text()
check('Council source and unresolved constraints explicit', all(x in t for x in [
    'اجتماعان على الأقل','ثلثي الأعضاء','C02','C24','C25','S016',
    'استمارة متابعة خطة الموجه الطلابي PDF7']) and 'القصيم ص47–49' not in t)
check('Noor matrix identity synchronized', sha(AFTER/rel) in (AFTER/mapping).read_text())
rp = Path('catalog/records_noor_decision_matrix.json')
x, y = json.loads((BEFORE/rp).read_text()), json.loads((AFTER/rp).read_text())
changed = []
for i, (u,v) in enumerate(zip(x['records'],y['records']),1):
    if u != v:
        changed.append(i)
        check(f'Record {i}: only operational_rule edited',
              {k:z for k,z in u.items() if k!='operational_rule'} ==
              {k:z for k,z in v.items() if k!='operational_rule'})
check('Record delta limited to 9,15,19,25', changed == [9,15,19,25])
check('Local capture honors current decisions', all(k in y['records'][24]['operational_rule']
    for k in ['DEC-019','DEC-020','موافقة ثانية','ليس إذنا بإدخال نور']))
registry = json.loads((AFTER/'catalog/source_registry.json').read_text())
q = next(s for s in registry['sources'] if s['source_id']=='REF-QASSIM-1448')
check('Current visual review is partial and hash-bound', q['visual_verification'][
    'verified_version_sha256']==sha(ROOT/'knowledge_sources/qassim.pdf')
    and len(q['visual_verification']['verified_pdf_pages'])==13)
manifest = json.loads((AFTER/'catalog/manifest.json').read_text())
for p in [timing, mapping, rel]:
    m = next(x for x in manifest['files'] if x['path']==str(p))
    check('Manifest current: '+p.name, m['sha256']==sha(AFTER/p)
          and m['size_bytes']==(AFTER/p).stat().st_size)
print('RESULT', len(checks), 'checks;', sum(c['passed'] for c in checks), 'passed')
if not all(c['passed'] for c in checks): raise SystemExit(1)
