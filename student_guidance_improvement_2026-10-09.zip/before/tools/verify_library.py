"""Read-only integrity check for registered fixed assets and source originals."""

from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path, PurePosixPath

try:
    from .check_work_register import validate_register
except ImportError:
    from check_work_register import validate_register


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(relative: str) -> dict:
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def validate_noor_matrix(matrix: dict, registry: dict, root: Path = ROOT) -> list[str]:
    """All declared source IDs and template paths must resolve directly."""
    errors: list[str] = []
    known = {item["source_id"] for item in registry["sources"]}
    context_path = matrix.get("current_context_path")
    context = (root / context_path).resolve() if isinstance(context_path, str) else None
    if context is None or not context.is_relative_to(root.resolve()) or not context.is_file():
        errors.append("Noor-matrix current context path does not resolve")
    for item in matrix.get("sources", []):
        if item.get("source_id") not in known:
            errors.append(f"unknown Noor-matrix source ID: {item.get('source_id')}")
    records = matrix.get("records", [])
    if len({item.get("record_id") for item in records}) != len(records):
        errors.append("duplicate Noor-matrix record ID")
    for item in records:
        relative = item.get("original_path")
        path = (root / relative).resolve() if isinstance(relative, str) else None
        if path is None or not path.is_relative_to(root.resolve()) or not path.is_file():
            errors.append(f"Noor-matrix template missing: {item.get('record_id')}: {relative}")
        for source_id in item.get("source_refs", []):
            if source_id not in known:
                errors.append(f"unknown Noor-matrix source ID: {source_id}")
    return errors


def main() -> int:
    errors: list[str] = []
    manifest = load("catalog/manifest.json")
    if manifest.get("file_count") != len(manifest["files"]):
        errors.append("manifest file_count mismatch")
    listed = [item["path"] for item in manifest["files"]]
    if len(listed) != len(set(listed)):
        errors.append("duplicate manifest path")
    for item in manifest["files"]:
        relative = PurePosixPath(item["path"])
        if relative.is_absolute() or ".." in relative.parts:
            errors.append(f"unsafe manifest path: {item['path']}")
            continue
        path = ROOT / relative
        if not path.is_file():
            errors.append(f"missing: {item['path']}")
        elif (
            ("size_bytes" in item and path.stat().st_size != item["size_bytes"])
            or sha256(path) != item["sha256"]
        ):
            errors.append(f"hash/size mismatch: {item['path']}")

    registry = load("catalog/source_registry.json")["sources"]
    for item in registry:
        source = ROOT / PurePosixPath(item["archive_path"])
        if not source.is_file() or sha256(source) != item["sha256"]:
            errors.append(f"original source mismatch: {item['source_id']}")

    matrix = load("catalog/records_noor_decision_matrix.json")
    errors.extend(validate_noor_matrix(matrix, {"sources": registry}))
    errors.extend(validate_register(load("work/register.json"), ROOT))
    if len(matrix["records"]) != 31:
        errors.append("expected 31 record mappings")
    archive = next((ROOT / PurePosixPath(item["archive_path"]) for item in registry if item["archive_path"].endswith(".zip")), None)
    if archive is None or not archive.is_file():
        errors.append("records ZIP missing")
    else:
        with zipfile.ZipFile(archive) as package:
            if package.testzip() is not None:
                errors.append("records ZIP failed CRC check")
            if len([entry for entry in package.infolist() if not entry.is_dir()]) != 31:
                errors.append("records ZIP does not contain 31 files")

    report = {
        "status": "pass" if not errors else "fail",
        "manifest_files": len(listed),
        "source_records": len(registry),
        "noor_matrix_records": len(matrix["records"]),
        "work_records": len(load("work/register.json")["items"]),
        "ocr_required": [item["source_id"] for item in registry if item.get("text_status") == "needs_ocr"],
        "errors": errors,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
